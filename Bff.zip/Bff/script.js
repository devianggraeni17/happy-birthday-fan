/* =====================================
   OPEN UCAPAN + MUSIC
===================================== */

const openBtn = document.getElementById("openBtn");
const opening = document.getElementById("opening");

const music = document.getElementById("music");
const musicBtn = document.getElementById("musicBtn");


openBtn.addEventListener("click", function () {

    // Hilangkan halaman pembuka
    opening.classList.add("hide");

    // Putar musik
    music.play()
        .then(function () {

            musicBtn.classList.add("playing");

        })
        .catch(function (error) {

            console.log(
                "Musik tidak dapat diputar:",
                error
            );

        });

});


/* =====================================
   MUSIC BUTTON
===================================== */

musicBtn.addEventListener("click", function () {

    if (music.paused) {

        music.play()
            .then(function () {

                musicBtn.classList.add("playing");

            });

    } else {

        music.pause();

        musicBtn.classList.remove("playing");

    }

});


/* =====================================
   SCROLL PROGRESS
===================================== */

window.addEventListener("scroll", function () {

    const scrollTop =
        window.scrollY;

    const documentHeight =
        document.documentElement.scrollHeight -
        window.innerHeight;

    const scrollPercent =
        (scrollTop / documentHeight) * 100;

    document.getElementById(
        "progressBar"
    ).style.width =
        scrollPercent + "%";

});


/* =====================================
   REVEAL ANIMATION
===================================== */

const animatedElements =
    document.querySelectorAll(
        ".section, .wish-section, .final-content"
    );


const revealObserver =
    new IntersectionObserver(
        function (entries) {

            entries.forEach(function (entry) {

                if (entry.isIntersecting) {

                    entry.target.classList.add("show");

                }

            });

        },
        {
            threshold: 0.12
        }
    );


animatedElements.forEach(function (element) {

    element.style.opacity = "0";

    element.style.transform =
        "translateY(40px)";

    element.style.transition =
        "opacity 1s ease, transform 1s ease";

    revealObserver.observe(element);

});


/* =====================================
   REVEAL STYLE
===================================== */

const revealStyle =
    document.createElement("style");

revealStyle.innerHTML = `

    .show {
        opacity: 1 !important;
        transform: translateY(0) !important;
    }

`;

document.head.appendChild(revealStyle);


/* =====================================
   FLOATING HEARTS
===================================== */

function createHeart() {

    const heart =
        document.createElement("div");

    heart.innerHTML = "♡";

    heart.style.position = "fixed";

    heart.style.left =
        Math.random() * 100 + "vw";

    heart.style.bottom = "-30px";

    heart.style.fontSize =
        (Math.random() * 15 + 10) + "px";

    heart.style.color =
        "rgba(228,169,181,.45)";

    heart.style.pointerEvents =
        "none";

    heart.style.zIndex = "1";

    heart.style.transition =
        "transform 6s linear, opacity 6s linear";

    document.body.appendChild(heart);


    setTimeout(function () {

        heart.style.transform =
            `translateY(-110vh) rotate(${Math.random() * 180}deg)`;

        heart.style.opacity = "0";

    }, 100);


    setTimeout(function () {

        heart.remove();

    }, 6500);

}


/* Buat hati setiap beberapa detik */

setInterval(createHeart, 1800);


/* =====================================
   CLICK EFFECT
===================================== */

document.addEventListener(
    "click",
    function (event) {

        // Jangan buat efek terlalu banyak
        if (
            event.target.closest(".music-btn") ||
            event.target.closest(".open-btn")
        ) {
            return;
        }


        const heart =
            document.createElement("span");

        heart.innerHTML = "♡";

        heart.style.position = "fixed";

        heart.style.left =
            event.clientX + "px";

        heart.style.top =
            event.clientY + "px";

        heart.style.color =
            "#e4a9b5";

        heart.style.fontSize = "20px";

        heart.style.pointerEvents =
            "none";

        heart.style.zIndex = "99999";

        heart.style.transition =
            "all 1s ease";


        document.body.appendChild(heart);


        setTimeout(function () {

            heart.style.transform =
                "translateY(-60px) scale(1.5)";

            heart.style.opacity = "0";

        }, 50);


        setTimeout(function () {

            heart.remove();

        }, 1100);

    }
);


/* =====================================
   PREVENT MUSIC ERROR
===================================== */

music.addEventListener(
    "error",
    function () {

        console.log(
            "File music.mp3 tidak ditemukan."
        );

    }
);


/* =====================================
   PAGE LOADED
===================================== */

window.addEventListener(
    "load",
    function () {

        document.body.classList.add(
            "loaded"
        );

    }
);